<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

//#Producto
/**
    * @OA\Get (
    *       path="/api/products/{id}",
    *       operationId="getProductById",
    *       tags={"Productos"},
    *       summary="Muestra un producto por id",
    *       description="Retorna un registro por id",
    *       @OA\Parameter(in="path", name="id", required=true, @OA\Schema(type="integer")),
    *       @OA\Response(
    *           response=200,
    *           description="success",
    *           @OA\JsonContent(
    *               @OA\Property(property="id", type="number", example=1),
    *               @OA\Property(property="name", type="string", example="Nombre producto"),
    *               @OA\Property(property="slug", type="string", example="nombre-producto"),
    *               @OA\Property(property="description", type="string", example="Descripción de producto"),
    *               @OA\Property(property="price", type="float", example="1000"),
    *               @OA\Property(property="updated_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *               @OA\Property(property="created_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *           )
    *       ),
    *       @OA\Response(response=403, description="Forbidden"),
    *       @OA\Response(response=404, description="Not Found", @OA\JsonContent(@OA\Property(property="message", type="string", example="Producto no existe"),))
    * ),
    * @OA\Get (
    *   path="/api/products",
    *   operationId="getProductsList",
    *   tags={"Productos"},
    *   summary="Listar todos los productos",
    *   description="Retorna lista de productos",
    *       @OA\Response(
    *           response=200,
    *           description="success",
    *           @OA\JsonContent(
    *               @OA\Property(type="array", property="products",
    *                   @OA\Items(type="object",
    *                       @OA\Property(property="id", type="number", example="1"),
    *                       @OA\Property(property="name", type="string", example="Ejemplo Nombre Producto"),
    *                       @OA\Property(property="slug", type="string", example="ejemplo-de-slug"),
    *                       @OA\Property(property="description", type="string",example="Ejemplo de descripción"),
    *                       @OA\Property(property="price", type="float", example="1000"),
    *                       @OA\Property(property="updated_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *                       @OA\Property(property="created_at",type="date", example="2022-05-21T00:43:54.000000Z")
    *                   )
    *               )
    *           )
    *       ),
    *       @OA\Response(response=401, description="Unauthenticated"),
    *       @OA\Response(response=403, description="Forbidden"),
    *       @OA\Response(response=400, description="Invalid"),
    *       @OA\Response(response=500, description="Internal Server Error", @OA\JsonContent(@OA\Property(property="message", type="string", example="SQLSTATE[HY000] [2002] No se puede establecer una conexión"),))
    * ),
    * @OA\Post (
    *   path="/api/products",
    *   operationId="postProduct",
    *   tags={"Productos"},
    *   summary="Crear nuevo producto",
    *   description="Retorna nuevo producto",
    *  
    *   @OA\RequestBody(
    *       @OA\MediaType(
    *           mediaType="application/json",
    *           @OA\Schema( required={"name"}, required={"slug"}, required={"price"},
    *               @OA\Property(type="object",
    *                   @OA\Property(property="name", type="string"),
    *                   @OA\Property(property="slug",type="string"),
    *                   @OA\Property(property="description",type="string"),
    *                   @OA\Property(property="price",type="float"),
    *                 ),
    *                 example={
    *                     "name":"Nombre de Producto",
    *                     "slug":"nombre-de-producto",
    *                     "description":"Descripción de Producto",
    *                     "price":"100.000",
    *                }
    *             )
    *         )
    *       ),
    *       @OA\Response(
    *          response=200,
    *          description="success",
    *          @OA\JsonContent(
    *              @OA\Property(property="id", type="number", example=1),
    *              @OA\Property(property="name", type="string", example="Nombre de Producto"),
    *              @OA\Property(property="slug", type="string", example="nombre-de-producto"),
    *              @OA\Property(property="description", type="string", example="Descripción de Producto"),
    *              @OA\Property(property="price", type="float", example="1000"),
    *              @OA\Property(property="updated_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *              @OA\Property(property="created_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *          )
    *       ),
    *       @OA\Response(response=401, description="Unauthenticated"),
    *       @OA\Response(response=400, description="Invalid"),
    *       @OA\Response(response=422, description="Unprocessable Content", @OA\JsonContent(@OA\Property(property="message", type="string", example="The given data was invalid. field is required"),))
    * ),
    * @OA\Put (
    *   path="/api/products/{id}",
    *   operationId="updateProduct",
    *   tags={"Productos"},
    *   summary="Actualiza un producto por id",
    *   description="Retorna el registro actualizado",
    *   @OA\Parameter(in="path", name="id", required=true, @OA\Schema(type="string")),
    *   @OA\RequestBody(
    *       @OA\MediaType(mediaType="application/json",
    *           @OA\Schema(
    *               @OA\Property(type="object",
    *                   @OA\Property(property="name", type="string"),
    *                   @OA\Property(property="slug", type="string"),
    *                   @OA\Property(property="description", type="string"),
    *                   @OA\Property(property="price", type="float"),
    *                 ),
    *                 example={
    *                     "name":"Actualiza Nombre",
    *                     "slug":"Actualiza Slug",
    *                     "description":"Actualiza Descripción",
    *                     "price":"110.000",
    *                   }
    *               )
    *           )
    *       ),
    *       @OA\Response(
    *           response=200,
    *           description="success",
    *           @OA\JsonContent(
    *               @OA\Property(property="id", type="number", example=1),
    *               @OA\Property(property="name", type="string", example="Actualizar Nombre"),
    *               @OA\Property(property="slug", type="string", example="actualizar-nombre-de-slug"),
    *               @OA\Property(property="description", type="string", example="Actualizar Descripción"),
    *               @OA\Property(property="price", type="float", example="900.000"),
    *               @OA\Property(property="updated_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *               @OA\Property(property="created_at", type="date", example="2022-05-21T00:43:54.000000Z")
    *          )
    *       ),
    *       @OA\Response(response=400, description="Bad Request"),
    *       @OA\Response(response=404, description="Resource Not Found")
    *       
    * ),
    * @OA\Delete (
    *   path="/api/products/{id}",
    *   operationId="deleteProduct",
    *   tags={"Productos"},
    *   summary="Elimina un producto por id",
    *   description="Retorna éxito de la eliminación",
    *   @OA\Parameter(
    *       in="path",
    *       name="id",
    *       required=true,
    *       @OA\Schema(type="string")
    *   ),
    *   @OA\Response(
    *       response=200,
    *       description="success",
    *       @OA\JsonContent(
    *           @OA\Property(property="message", type="string", example="Producto eliminado con éxito")
    *       )
    *   )
    * ),
    * @OA\Get (
    *   path="/api/products/search/{name}",
    *   operationId="searchProductByName",
    *   tags={"Productos"},
    *   summary="Busca productos por nombre",
    *   description="Retorna registros por el nombre de producto",
    *   @OA\Parameter(in="path", name="name", required=true, @OA\Schema(type="string")),
    *   @OA\Response(
    *       response=200,
    *       description="success",
    *       @OA\JsonContent(
    *           @OA\Property(property="id", type="number", example=1),
    *           @OA\Property(property="name", type="string", example="Nombre producto"),
    *           @OA\Property(property="slug", type="string", example="nombre-producto"),
    *           @OA\Property(property="description", type="string", example="Descripción de producto"),
    *           @OA\Property(property="price", type="float", example="1000"),
    *           @OA\Property(property="updated_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *           @OA\Property(property="created_at", type="date", example="2022-05-21T00:43:54.000000Z"),
    *       )
    *   ),
    *   @OA\Response(response=403, description="Forbidden"),
    *   @OA\Response(response=404, description="Not Found", @OA\JsonContent(@OA\Property(property="message", type="string", example="Producto no existe"),))
    * ),
*/
class SwaggerController extends Controller
{
    //
}
